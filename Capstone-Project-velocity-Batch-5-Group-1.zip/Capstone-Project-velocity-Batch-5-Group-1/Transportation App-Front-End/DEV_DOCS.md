Please have a look at [Nebular Dev Docs](https://github.com/akveo/nebular/blob/master/DEV_DOCS.md).
