export class Search {
 
    from:string;
    to:string;
    date:string;
    time:string;
    service:string
}