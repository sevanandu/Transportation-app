import { NgModule } from '@angular/core';
import {
  NbButtonModule,
  NbCardModule,
  NbProgressBarModule,
  NbTabsetModule,
  NbUserModule,
  NbIconModule,
  NbSelectModule,
  NbListModule,
  NbTimepickerModule,
} from '@nebular/theme';
import {
  NbActionsModule,

  NbCheckboxModule,
  NbDatepickerModule, 
  NbInputModule,
  NbRadioModule,
} from '@nebular/theme';
import { NgxEchartsModule } from 'ngx-echarts';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { ThemeModule } from '../../@theme/theme.module';
import { ECommerceComponent } from './e-commerce.component';
import { FormsModule, FormsModule as ngFormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    ThemeModule,
    NbCardModule,
    NbUserModule,
    NbButtonModule,
    NbIconModule,
    NbTabsetModule,
    NbSelectModule,
    NbProgressBarModule,
    NgxEchartsModule,
    NgxChartsModule,
    NbInputModule,
    NbCheckboxModule,
    NbRadioModule,
    NbDatepickerModule,
    NbTimepickerModule,
    NbTimepickerModule.forRoot(),
    FormsModule,
    ReactiveFormsModule  
  ],
  declarations: [
    ECommerceComponent
  ],
  providers: [
  ],
})
export class ECommerceModule { }
