import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BaseServiceService {

  constructor(private http: HttpClient) { }

  login(postData) {


    const body = new HttpParams()
    .set('grant_type','password')
    .set('username', postData.username)
    .set('password', postData.password);

  return this.http.post('http://localhost:9191/auth-api/oauth/token',
    body.toString(),
    {
      headers: new HttpHeaders()
        .set('Content-Type', 'application/x-www-form-urlencoded')
        .set('Authorization', 'Basic ' + btoa('mobile:pin'))
    }
  );


    return this.http.post('http://localhost:9191/auth-api/oauth/token', postData, { observe: 'response' })
  }

  findUser(postData) {
    return this.http.post('http://localhost:9191/auth-api/find', postData, { observe: 'response' })
  }

  /**
   * Function -- forgotPassword()
   * Use -- API for forgot password.
   * @param postData 
   */
  forgotPassword(postData) {
    return this.http.put('http://localhost:9191/auth-api/updatePassword', postData, { observe: 'response' });
  }
  search(postData) {
    return this.http.post('http://localhost:8180/sales-api/transport', postData, { observe: 'response' });
  }
  update(postData) {
    return this.http.put('http://localhost:9191/auth-api/updateUser', postData, { observe: 'response' });
  }
  list(id) {
    return this.http.get('http://localhost:8180/item-api/wish-find/' + id, { observe: 'response' });
  }

  addWishList(postData) {
    return this.http.post('http://localhost:8180/item-api/wish-save',postData, { observe: 'response' });
  }

  deleteWish(id) {
    return this.http.delete('http://localhost:8180/item-api/wish-delete/'+id, { observe: 'response' });
  }
  register(postData){
    return this.http.post('http://localhost:9191/auth-api/saveUser',postData, { observe: 'response' });
  }



}
