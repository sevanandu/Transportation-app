
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { getDeepFromObject, NbAuthResult, NbAuthSocialLink, NB_AUTH_OPTIONS } from '@nebular/auth';
import { BaseServiceService } from '../../e-commerce/base-service.service';


@Component({
  selector: 'ngx-form-layouts',
  styleUrls: ['./form-layouts.component.scss'],
  templateUrl: './form-layouts.component.html',
})
export class FormLayoutsComponent {


  redirectDelay: number = 0;
  showMessages: any = {};
  strategy: string = '';

  submitted = false;
  errors: string[] = [];
  messages: string[] = [];
  user: any = {};
  socialLinks: NbAuthSocialLink[] = [];

  constructor(protected service: BaseServiceService,
    @Inject(NB_AUTH_OPTIONS) protected options = {},
    protected cd: ChangeDetectorRef,
    protected router: Router) {

    this.redirectDelay = this.getConfigValue('forms.register.redirectDelay');
    this.showMessages = this.getConfigValue('forms.register.showMessages');
    this.strategy = this.getConfigValue('forms.register.strategy');
    this.socialLinks = this.getConfigValue('forms.login.socialLinks');
  }

  register(): void {
    this.errors = this.messages = [];
    this.submitted = true;

    let request = {
      "username": this.user.fullName,
      "password": this.user.password,
      "email": this.user.email,
      "enabled": true,
      "accountNonExpired": true,
      "credentialsNonExpired": true,
      "accountNonLocked": true,
      "roles": [{
        "id": 1,
        "permissions": [{
          "id": 1
        }]
      }]

    }


    this.service.register(request).subscribe((result: any) => {
      this.submitted = false;
      console.log(result);

      if (result.status == 200) {

        this.router.navigateByUrl("/auth/login");
      } else {
        this.errors = result.getErrors();
      }

    });
  }

  getConfigValue(key: string): any {
    return getDeepFromObject(this.options, key, null);
  }

}
