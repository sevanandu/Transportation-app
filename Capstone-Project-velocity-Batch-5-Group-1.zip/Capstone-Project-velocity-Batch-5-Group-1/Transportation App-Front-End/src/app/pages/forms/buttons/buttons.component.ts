import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { getDeepFromObject, NbAuthService, NbAuthSocialLink, NbTokenService, NB_AUTH_OPTIONS } from '@nebular/auth';
import { NbComponentShape, NbComponentSize, NbComponentStatus, NbToastrService } from '@nebular/theme';

import { BaseServiceService } from '../../e-commerce/base-service.service';

@Component({
  selector: 'ngx-buttons',
  styleUrls: ['./buttons.component.scss'],
  templateUrl: './buttons.component.html',
})
export class ButtonsComponent {
  statuses: NbComponentStatus[] = [ 'primary', 'success', 'info', 'warning', 'danger' ];
  shapes: NbComponentShape[] = [ 'rectangle', 'semi-round', 'round' ];
  sizes: NbComponentSize[] = [ 'tiny', 'small', 'medium', 'large', 'giant' ];


   //Variable declaration
   redirectDelay: number = 0;
   showMessages: any = {};
   strategy: string = '';
   dateForCopyRight:any;
   yearForCopyRight:any;
   checkExpStatus:any;
   loading : boolean = false;
   errors: string[] = [];
   messages: string[] = [];
   user: any = {};
 password:string;
 username:string;
 
   submitted: boolean = false;
   socialLinks: NbAuthSocialLink[] = [];
   rememberMe = false;
   public token: any;
   isZohoAuthenticated : boolean;
 
   //Constructor and Dependency Injection
   constructor(protected service: NbAuthService,
     @Inject(NB_AUTH_OPTIONS) protected options = {},
     protected cd: ChangeDetectorRef,
     protected tokenService: NbTokenService,
     protected router: Router,
     private toastr: NbToastrService,
     private authService : BaseServiceService) {
     this.redirectDelay = this.getConfigValue('forms.login.redirectDelay');
     this.showMessages = this.getConfigValue('forms.login.showMessages');
     this.strategy = this.getConfigValue('forms.login.strategy');
     this.socialLinks = this.getConfigValue('forms.login.socialLinks');
     this.rememberMe = this.getConfigValue('forms.login.rememberMe');
     this.dateForCopyRight = new Date();
     this.yearForCopyRight = this.dateForCopyRight.getFullYear();
   }
 
 
   /**
    * Function -- login
    * Use -- This function will be called when user press login button
    */
   login(): void {
     this.loading = true;
     this.errors = [];
     this.messages = [];
     this.submitted = true;
let request={
"username":this.username,
"password":this.password
}

 console.log(request);
 
     this.authService.login(request).subscribe((result: any) => {
       this.submitted = false;
       console.log(result);
       
       if (result) {        
        
         localStorage.setItem('access_token',JSON.stringify(result));
        
         this.authService.findUser(request).subscribe((resultt: any) => {
          localStorage.setItem('user_details', JSON.stringify(resultt.body));
          return this.router.navigateByUrl('/pages/dashboard');
         },
         (err : HttpErrorResponse) => {
          if (err.status == 401) {
            setTimeout(() => {
              this.loading = false;
              this.toastr.danger("Invalid Credentials", 'Error');
            });
         
          }});
       } 
       this.cd.detectChanges();
     }, (err : HttpErrorResponse) => {
       if (err.status == 401) {
         setTimeout(() => {
           this.loading = false;
           this.toastr.danger("Invalid Credentials", 'Error');
         });
       }
       else {
         this.loading = false;
         this.toastr.danger(err.error.errors, 'Error');
       }
     });
   }
 
   getConfigValue(key: string): any {
     return getDeepFromObject(this.options, key, null);
   }
}
