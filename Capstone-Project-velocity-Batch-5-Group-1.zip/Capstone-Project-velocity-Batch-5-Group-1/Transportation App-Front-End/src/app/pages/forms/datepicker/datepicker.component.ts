import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { Route, Router } from '@angular/router';
import { NbDateService, NbToastrService } from '@nebular/theme';
import { BaseServiceService } from '../../e-commerce/base-service.service';

@Component({
  selector: 'ngx-datepicker',
  templateUrl: 'datepicker.component.html',
  styleUrls: ['datepicker.component.scss'],
})
export class DatepickerComponent {

  min: Date;
  max: Date;
  password:string;
  newPassword:string;

  constructor(protected dateService: NbDateService<Date>, private http: HttpClient, private authService: BaseServiceService,
    private toastr: NbToastrService, private router: Router) {
    this.min = this.dateService.addDay(this.dateService.today(), -5);
    this.max = this.dateService.addDay(this.dateService.today(), 5);
  }


  user: any;
  userDetails: any = [];
  result: any = {};
  error: any;
  loading = false;
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$";


  ngOnInit() {

    // initialize model here
    this.user = {
      email: ''
    }
  }

  /**
   * Function -- onSaveForm()
   * Use -- When User click the submit buttons
   * @param formData 
   */
  onSaveForm(formData) {
    this.loading = true;
    let tokenMy:any=JSON.parse(localStorage.getItem('user_details'));
let request ={
  "id":tokenMy.id,
"password": this.password ,
  "newPassword":this.newPassword
}

    this.authService.forgotPassword(request).subscribe((res: any) => {
      if (res) {
        this.loading = false;
        this.toastr.success(res.message, 'Success');
        setTimeout(() => {
          return this.router.navigateByUrl('/auth/login');
        }, 2000);
      }
    },
      (error: HttpErrorResponse) => {
        this.loading = false;
        this.toastr.danger(error.error.message, 'Error');
      });
  }
}
