import { Component, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { getDeepFromObject, NB_AUTH_OPTIONS } from '@nebular/auth';
import { BaseServiceService } from '../../e-commerce/base-service.service';

@Component({
  selector: 'ngx-form-inputs',
  styleUrls: ['./form-inputs.component.scss'],
  templateUrl: './form-inputs.component.html',
})
export class FormInputsComponent {

  starRate = 2;
  heartRate = 4;
  radioGroupValue = 'This is value 2';
  username:string;
  email:string;

  constructor(
    @Inject(NB_AUTH_OPTIONS) protected options = {},
    protected router: Router,
    private baseService: BaseServiceService
  ) {


  }

  submit(form: any) {
console.log(form.value);
let tokenMy:any=JSON.parse(localStorage.getItem('user_details'));
let request={
  "username":this.username,
  "email":this.email,
  "id":tokenMy.id
}
console.log(request);

    this.baseService.update(request).subscribe((result: any) => {

      if (result.status != 500) {
        console.log(result);

      }

    });
  }

  getConfigValue(key: string): any {
    return getDeepFromObject(this.options, key, null);
  }

}
