import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NB_AUTH_OPTIONS } from '@nebular/auth';
import { NbThemeService, NbToastrService } from '@nebular/theme';
import { takeWhile } from 'rxjs/operators';
import { SolarData } from '../../@core/data/solar';
import { BaseServiceService } from '../e-commerce/base-service.service';
import * as L from 'leaflet';
import $ from 'jquery';
interface CardSettings {
  title: string;
  iconClass: string;
  type: string;
}

@Component({
  selector: 'ngx-dashboard',
  styleUrls: ['./dashboard.component.scss'],
  templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnDestroy, OnInit {

  private alive = true;

  public wishList: [];

  solarValue: number;
  lightCard: CardSettings = {
    title: 'Light',
    iconClass: 'nb-lightbulb',
    type: 'primary',
  };
  rollerShadesCard: CardSettings = {
    title: 'Roller Shades',
    iconClass: 'nb-roller-shades',
    type: 'success',
  };
  wirelessAudioCard: CardSettings = {
    title: 'Wireless Audio',
    iconClass: 'nb-audio',
    type: 'info',
  };
  coffeeMakerCard: CardSettings = {
    title: 'Coffee Maker',
    iconClass: 'nb-coffee-maker',
    type: 'warning',
  };

  statusCards: string;

  commonStatusCardsSet: CardSettings[] = [
    this.lightCard,
    this.rollerShadesCard,
    this.wirelessAudioCard,
    this.coffeeMakerCard,
  ];

  statusCardsByThemes: {
    default: CardSettings[];
    cosmic: CardSettings[];
    corporate: CardSettings[];
    dark: CardSettings[];
  } = {
      default: this.commonStatusCardsSet,
      cosmic: this.commonStatusCardsSet,
      corporate: [
        {
          ...this.lightCard,
          type: 'warning',
        },
        {
          ...this.rollerShadesCard,
          type: 'primary',
        },
        {
          ...this.wirelessAudioCard,
          type: 'danger',
        },
        {
          ...this.coffeeMakerCard,
          type: 'info',
        },
      ],
      dark: this.commonStatusCardsSet,
    };

  constructor(private themeService: NbThemeService,
    private solarService: SolarData,
    @Inject(NB_AUTH_OPTIONS) protected options = {},
    protected router: Router,
    private baseService: BaseServiceService,
    private toastr: NbToastrService

  ) {
    this.themeService.getJsTheme()
      .pipe(takeWhile(() => this.alive))
      .subscribe(theme => {
        this.statusCards = this.statusCardsByThemes[theme.name];
      });

    this.solarService.getSolarData()
      .pipe(takeWhile(() => this.alive))
      .subscribe((data) => {
        this.solarValue = data;
      });
  }
  ngOnInit(): void {
    let tokenMy: any = JSON.parse(localStorage.getItem('user_details'));
    this.baseService.list(tokenMy.id).subscribe((result: any) => {
      console.log(result);
      
      this.wishList=result.body;
      if (result.status != 500) {
        console.log(result);

      }

    });

  }

  ngOnDestroy() {
    this.alive = false;
  }
  deleteWhiteList(id){
       
    this.baseService.deleteWish(id).subscribe((result: any) => {
      this.toastr.danger("Delete successfully ", 'Success');
      this.ngOnInit();
    }, (err : HttpErrorResponse) => {
      if (err.status == 401) {
        setTimeout(() => {
        
          this.toastr.danger("Invalid Credentials", 'Error');
        });
     
      }});
  }
  getWishList(val:any){
        console.log(val);

        
        this.baseService.search(JSON.parse(val.itemName)).subscribe((result: any) => {

          if (result.status != 500) {
            console.log(result.body);
            const map = this.drawMap();
            const route = result.body.routes[0]
            const routeParts = route.route_parts.map(routePart => routePart.coordinates)
            this.drawGeometry(routeParts, map)
    
            const journeyStepsHtml = route.route_parts
              .map(routePart => {
                const lineName = routePart.mode === 'bus' ? routePart.line_name : ''
                return `
                  <div>
                    <b>${routePart.departure_time}</b> ${routePart.from_point_name}
                    <div class="leg-details">
                      <span class="mode mode-${routePart.mode}"></span> ${lineName}
                      for ${routePart.duration.slice(0, 5)}
                    </div>
                  </div>
                `
              })
              .join('\n')
            $('#app').html(`
              Duration: ${route.duration.slice(0, 5)}
              <span class="duration-from-to">${route.departure_time} - ${route.arrival_time}</span>
              <div class="legs">
                ${journeyStepsHtml}
                <div>
                  <b>${route.route_parts[route.route_parts.length - 1].arrival_time}</b> Destination
                </div>
              </div>
            `)
    
          }
    
        });
        
  }


  
  drawMap() {
    const map = L.map('mapElement').setView([51.505, -0.09], 13)
    const urlTemplate = 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png'
    console.log(urlTemplate);

    map.addLayer(L.tileLayer(urlTemplate, {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; ' +
        '<a href="https://carto.com/attributions">CARTO</a>',
      subdomains: ['a', 'b', 'c', 'd'],
      maxZoom: 19,
      id: 'map',
      tileSize: 512,
      zoomOffset: -1
    }))
    return map
  }

  drawGeometry(routeParts, map) {
    const edgesLayerGroup = L.layerGroup()
    map.addLayer(edgesLayerGroup)
    const polyLines = routeParts.map(routePart =>
      // The coordinates are returned as [longitude, latitude] so they need to be swapped before they're passed to Leaflet
      routePart.map(point => [point[1], point[0]]))
    polyLines.forEach(polyLine => {
      edgesLayerGroup.addLayer(L.polyline(polyLine))
    })

    map.fitBounds(polyLines.flat(1))
  }

}
